# Interactive Navigation Menu

Fixed navigation menu with hover and scroll effects using HTML, CSS, and JavaScript.
